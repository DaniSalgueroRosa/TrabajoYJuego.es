# FP Cuenta: ideas guardadas

Lo que se habló y se decidió sobre el futuro de la web (12 de noviembre de 2026). Lo marcado en «Hecho» ya está en la web; lo demás sigue pendiente.

## Aprobadas (hacer cuando toque)

### 1. Más guías (la sección de artículos ya existe)
Ya hay siete guías con fuentes y fecha de revisión (ver «Hecho»). Siguen pendientes, cada una con fuentes oficiales:
- Qué es la FCT y cómo se evalúa.
- Convocatorias: cuántas hay y qué pasa si suspendes un módulo (en Andalucía hay hasta 4 convocatorias por módulo).
- Cuántas faltas puedes tener, una guía por comunidad (Andalucía, Madrid, Cataluña).
- Convalidaciones y exenciones de módulos.
- FP dual: cómo funciona.
Una guía por semana, bien hecha, mejor que muchas de golpe. Se añade un archivo en `gen/articulos/` y se ejecuta `construir.py`
(formato en `gen/articulos.py`).

### 2. Calculadora de nota media del ciclo y de nota de admisión a la universidad
Nota media del ciclo a partir de las notas de los módulos y nota de admisión (media del ciclo más la fase de admisión opcional).
Según lo que se ha revisado, la nota del ciclo es la **media aritmética simple** de las notas de los módulos, con dos decimales
(no se pondera por horas). Hay que volver a comprobar la normativa vigente antes de escribirla.

### 3. Calculadora de FCT
Horas de FCT (formación en centros de trabajo) por ciclo y comunidad, horas por día y fecha estimada de fin según el calendario
que escriba la persona.

## Hecho
- Siete guías propias con fuentes (faltas, evaluación continua, justificadas, nota del módulo, RA, grado medio y superior, cómo llevar la cuenta) y su sección «Guías».
- Parte legal reorganizada: aviso legal, privacidad, cookies y sobre nosotros con los datos del titular en `gen/sitio.json`.
- Guía de publicación (`PUBLICAR.md`) y `gen/empaquetar.py` para crear el zip que se sube.
- Modo oscuro con botón en la cabecera (ver LEEME).
- Preparación de AdSense: ID en un solo archivo, metaetiqueta, `ads.txt`, huecos de anuncio, mensaje de consentimiento de Google.

## Descartadas
- **Resultados de aprendizaje reales de cada módulo.** Basta con «RA 1, RA 2…» y la persona escribe los pesos. No se cargan los RA oficiales
  (`datos/ra.js` queda vacío a propósito).
- **Una página por comunidad o por ciclo.** Se queda como está: una calculadora y una página de normativa.

## Aplazadas
- **Web instalable y sin conexión (PWA).** Todavía no: añade complicaciones (versiones en caché, actualizaciones) que ahora no compensan.
