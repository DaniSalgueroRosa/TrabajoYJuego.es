# -*- coding: utf-8 -*-
"""
Revisa la web antes de subirla y de pedir AdSense. No modifica nada.

Comprueba tres cosas:
  1. Lo que tienes que rellenar tú (titular, dominio, correo, ID de AdSense).
  2. Que la web cumple lo que AdSense y Google piden de un sitio: páginas legales enlazadas desde todas partes,
     contenido propio suficiente, títulos y descripciones únicos, enlaces internos que funcionan, sitemap y robots.
  3. Que los anuncios solo tienen hueco en páginas con contenido.

Uso:  python3 -I gen/antes_de_publicar.py        (desde cualquier carpeta)
Termina con código 0 si no queda nada pendiente y con 1 si falta algo.
"""
import glob
import json
import os
import re
import sys
from html.parser import HTMLParser
from urllib.parse import urlsplit

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
pendiente, avisos, listo = [], [], []

PALABRAS_MIN_GUIA = 600            # una guía con menos texto es poco contenido
PALABRAS_MIN_CON_ANUNCIO = 400     # una página con hueco de anuncio necesita texto propio
MIN_GUIAS = 5
PAGINAS_LEGALES = {
    "informacion/aviso-legal.html": "Aviso legal",
    "informacion/politica-de-privacidad.html": "Política de privacidad",
    "informacion/politica-de-cookies.html": "Política de cookies",
    "informacion/contacto.html": "Contacto",
    "informacion/sobre-nosotros.html": "Sobre nosotros",
}


def leer(ruta):
    with open(os.path.join(RAIZ, ruta), encoding="utf-8") as f:
        return f.read()


def clave(js, nombre):
    m = re.search(r"^\s*%s\s*:\s*'([^']*)'" % nombre, js, re.M)
    return m.group(1).strip() if m else ""


class Pagina(HTMLParser):
    """Saca de una página lo que revisamos: título, descripción, canonical, enlaces, ids y texto de <main>."""

    def __init__(self, texto):
        super().__init__(convert_charrefs=True)
        self.title = self.desc = self.canonical = self.robots = ""
        self.lang = ""
        self.viewport = False
        self.h1 = 0
        self.ids, self.enlaces, self.blank_sin_rel = set(), [], []
        self.anuncios = 0
        self.palabras = 0
        self._en_title = False
        self._main = 0
        self._ignorar = 0
        self._texto = []
        self.feed(texto)

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "html":
            self.lang = a.get("lang", "")
        elif tag == "title":
            self._en_title = True
        elif tag == "meta":
            n = (a.get("name") or "").lower()
            if n == "description":
                self.desc = a.get("content", "")
            elif n == "robots":
                self.robots = a.get("content", "")
            elif n == "viewport":
                self.viewport = True
        elif tag == "link" and (a.get("rel") or "") == "canonical":
            self.canonical = a.get("href", "")
        if a.get("id"):
            self.ids.add(a["id"])
        if tag == "a" and a.get("href"):
            self.enlaces.append(a["href"])
            if a.get("target") == "_blank" and "noopener" not in (a.get("rel") or ""):
                self.blank_sin_rel.append(a["href"])
        if tag == "h1":
            self.h1 += 1
        if "data-anuncio" in a:
            self.anuncios += 1
        if tag == "main":
            self._main += 1
        if tag in ("script", "style", "noscript"):
            self._ignorar += 1

    def handle_endtag(self, tag):
        if tag == "title":
            self._en_title = False
        elif tag == "main":
            self._main -= 1
        elif tag in ("script", "style", "noscript"):
            self._ignorar -= 1

    def handle_data(self, data):
        if self._en_title:
            self.title += data
        if self._main > 0 and not self._ignorar:
            self._texto.append(data)

    def close(self):
        super().close()
        self.palabras = len(re.findall(r"\w+", " ".join(self._texto)))


def cargar_paginas():
    rutas = sorted(os.path.relpath(p, RAIZ) for p in glob.glob(os.path.join(RAIZ, "**", "*.html"), recursive=True)
                   if os.sep + "gen" + os.sep not in p and not os.path.relpath(p, RAIZ).startswith("gen" + os.sep))
    paginas = {}
    for r in rutas:
        p = Pagina(leer(r))
        p.close()
        paginas[r] = p
    return paginas


def resolver(origen, href):
    """Ruta (desde la raíz) y ancla a la que apunta un enlace interno; None si es externo."""
    if re.match(r"^[a-z][a-z0-9+.-]*:", href, re.I) or href.startswith("//"):
        return None
    partes = urlsplit(href)
    if not partes.path:
        return origen, partes.fragment
    if partes.path.startswith("/"):
        destino = partes.path.lstrip("/")
    else:
        destino = os.path.normpath(os.path.join(os.path.dirname(origen), partes.path))
    if destino in ("", ".") or destino.endswith("/"):
        destino = os.path.join(destino, "index.html")
    return destino, partes.fragment


def url_canonica(dominio, ruta):
    if ruta == "index.html":
        return dominio + "/"
    return dominio + "/" + (ruta[:-5] if ruta.endswith(".html") else ruta)


# ---------------------------------------------------------------- 1) Lo que rellenas tú
sitio = json.loads(leer("gen/sitio.json"))
dominio = str(sitio.get("dominio", "")).rstrip("/")
cfg = leer("compartido/configuracion.js")
paginas = cargar_paginas()

if "tudominio" in dominio:
    pendiente.append("Dominio: gen/sitio.json sigue con %s. Escribe tu dominio real en «dominio» (con https:// y sin barra final) y ejecuta "
                     "gen/construir.py: cambia canonical, sitemap.xml, robots.txt y los datos estructurados." % dominio)
else:
    listo.append("Dominio: %s" % dominio)

titular = sitio.get("titular", {})
faltan = [k for k, etiqueta in (("nombre", "nombre y apellidos o razón social"), ("nif", "NIF o CIF"), ("domicilio", "domicilio"))
          if not str(titular.get(k, "")).strip()]
if faltan:
    pendiente.append("Titular: faltan en gen/sitio.json → titular: %s. Son obligatorios en el aviso legal (artículo 10 de la LSSI-CE)." % ", ".join(faltan))
else:
    listo.append("Datos del titular rellenados.")
if not str(sitio.get("hosting", "")).strip():
    pendiente.append("Alojamiento: escribe en gen/sitio.json → hosting quién aloja la web (p. ej. «Cloudflare, Inc.»). Sale en la política de privacidad.")

correo = clave(cfg, "contactEmail")
if "tudominio" in correo or not correo:
    pendiente.append("contactEmail sigue siendo %r: pon tu correo de contacto en compartido/configuracion.js (sale en las páginas legales y en el formulario)." % correo)
else:
    listo.append("Correo de contacto configurado.")
if clave(cfg, "suggestionsEndpoint"):
    listo.append("Buzón de sugerencias: se envía al servicio configurado. Escribe su nombre en gen/sitio.json → formulario.")
    if not str(sitio.get("formulario", "")).strip():
        pendiente.append("Buzón de sugerencias: usas un servicio externo (suggestionsEndpoint) pero gen/sitio.json → formulario está vacío. "
                         "Escribe su nombre (p. ej. «Formspree»): la política de privacidad tiene que nombrarlo.")
else:
    listo.append("Buzón de sugerencias: sin servicio externo (abre el programa de correo de la persona). Es válido.")

restantes = {p: len(re.findall(r'class="placeholder"', leer(p))) for p in paginas}
restantes = {p: n for p, n in restantes.items() if n}
if restantes:
    pendiente.append("Quedan %d marcadores amarillos en: %s. Se rellenan con gen/sitio.json y configuracion.js y volviendo a ejecutar construir.py."
                     % (sum(restantes.values()), ", ".join(sorted(restantes))))
else:
    listo.append("Los textos legales no tienen marcadores pendientes.")

# ---------------------------------------------------------------- 2) AdSense
ads = clave(cfg, "adsenseClient")
modo = clave(cfg, "consentimiento") or "propio"
if not ads:
    pendiente.append("AdSense: aún no hay ID. Cuando te registres, escribe adsenseClient en compartido/configuracion.js y ejecuta construir.py "
                     "(así salen la metaetiqueta y ads.txt).")
else:
    meta = '<meta name="google-adsense-account" content="%s">' % ads
    sin_meta = [p for p in paginas if meta not in leer(p)]
    if sin_meta:
        pendiente.append("AdSense: el ID está en configuracion.js pero falta la metaetiqueta en %s. Ejecuta de nuevo gen/construir.py." % ", ".join(sin_meta))
    else:
        listo.append("AdSense: metaetiqueta en todas las páginas (%s)." % ads)
    linea = "google.com, %s, DIRECT, f08c47fec0942fa0" % ads.replace("ca-", "", 1)
    if linea in leer("ads.txt"):
        listo.append("ads.txt con tu ID.")
    else:
        pendiente.append("ads.txt no tiene tu ID. Ejecuta de nuevo gen/construir.py.")
    if modo == "google":
        listo.append("Consentimiento: lo muestra Google. Comprueba en AdSense → Privacidad y mensajes que el mensaje de normativa europea está publicado para tu sitio.")
    else:
        pendiente.append("Consentimiento: usas el aviso propio. Para mostrar anuncios a visitas de la UE y el Reino Unido, Google exige una plataforma de consentimiento "
                         "certificada: pon consentimiento: 'google' en configuracion.js y publica el mensaje en AdSense → Privacidad y mensajes.")
    bloque = re.search(r"adsenseSlots\s*:\s*\{(.*?)\}", cfg, re.S)
    huecos = re.findall(r"^\s*(\w+)\s*:\s*'(\d*)'", bloque.group(1), re.M) if bloque else []
    sin = [k for k, v in huecos if not v]
    if sin and len(sin) == len(huecos):
        avisos.append("Bloques de anuncios sin configurar: solo funcionarán los anuncios automáticos (actívalos en AdSense) o añade los números en adsenseSlots.")
    elif sin:
        avisos.append("Bloques de anuncios sin número (no se mostrarán): %s." % ", ".join(sin))
    else:
        listo.append("Bloques de anuncios configurados: %s." % ", ".join(k for k, _ in huecos))

# ---------------------------------------------------------------- 3) Archivos técnicos
for archivo in ("robots.txt", "sitemap.xml", "ads.txt", "404.html"):
    if os.path.exists(os.path.join(RAIZ, archivo)):
        listo.append("Existe %s." % archivo)
    else:
        pendiente.append("Falta %s: ejecuta gen/construir.py." % archivo)

if os.path.exists(os.path.join(RAIZ, "robots.txt")):
    robots = leer("robots.txt")
    if "Disallow: /" in re.sub(r"Disallow:\s*\n", "", robots) and re.search(r"^Disallow:\s*/\s*$", robots, re.M):
        pendiente.append("robots.txt bloquea todo el sitio (Disallow: /). Google no podría rastrearlo ni verificarlo para AdSense.")
    if ("Sitemap: %s/sitemap.xml" % dominio) not in robots:
        pendiente.append("robots.txt no apunta a %s/sitemap.xml. Ejecuta de nuevo gen/construir.py." % dominio)

# ---------------------------------------------------------------- 4) Requisitos de contenido y legales, página a página
indexables = {p: pg for p, pg in paginas.items() if "noindex" not in pg.robots and p != "404.html"}

# Sitemap = páginas indexables, con la URL canónica
if os.path.exists(os.path.join(RAIZ, "sitemap.xml")):
    en_sitemap = set(re.findall(r"<loc>([^<]+)</loc>", leer("sitemap.xml")))
    esperadas = {url_canonica(dominio, p) for p in indexables}
    if en_sitemap != esperadas:
        falta = sorted(esperadas - en_sitemap)
        sobra = sorted(en_sitemap - esperadas)
        pendiente.append("sitemap.xml no coincide con las páginas: faltan %s; sobran %s. Ejecuta gen/construir.py." % (falta or "ninguna", sobra or "ninguna"))
    else:
        listo.append("sitemap.xml lista las %d páginas indexables, con su dirección sin .html (la que sirven Cloudflare Pages y Netlify)." % len(esperadas))

problemas = {"titulo": [], "desc": [], "h1": [], "canon": [], "lang": [], "legal": [], "enlaces": [], "rel": [], "anuncio": [], "robots": []}
titulos, descripciones = {}, {}
for ruta, pg in sorted(paginas.items()):
    if not pg.title.strip():
        problemas["titulo"].append(ruta)
    if pg.h1 != 1:
        problemas["h1"].append("%s (%d)" % (ruta, pg.h1))
    if not pg.lang.startswith("es") or not pg.viewport:
        problemas["lang"].append(ruta)
    if ruta in indexables:
        if not (70 <= len(pg.desc) <= 170):
            problemas["desc"].append("%s (%d caracteres)" % (ruta, len(pg.desc)))
        titulos.setdefault(pg.title.strip(), []).append(ruta)
        descripciones.setdefault(pg.desc.strip(), []).append(ruta)
        if pg.canonical != url_canonica(dominio, ruta):
            problemas["canon"].append("%s → %s" % (ruta, pg.canonical or "sin canonical"))
    elif ruta == "404.html" and "noindex" not in pg.robots:
        problemas["robots"].append(ruta)
    # Las páginas legales y de contacto tienen que estar enlazadas desde todas partes (pie)
    destinos = {resolver(ruta, h)[0] for h in pg.enlaces if resolver(ruta, h)}
    faltan_legales = [n for r, n in PAGINAS_LEGALES.items() if r not in destinos and r != ruta]
    if faltan_legales:
        problemas["legal"].append("%s (sin enlace a: %s)" % (ruta, ", ".join(faltan_legales)))
    # Enlaces internos y anclas
    for h in pg.enlaces:
        r = resolver(ruta, h)
        if not r:
            continue
        destino, ancla = r
        if destino not in paginas and not os.path.exists(os.path.join(RAIZ, destino)):
            problemas["enlaces"].append("%s → %s" % (ruta, h))
        elif ancla and destino in paginas and ancla not in paginas[destino].ids:
            problemas["enlaces"].append("%s → %s (no existe #%s)" % (ruta, h, ancla))
    if pg.blank_sin_rel:
        problemas["rel"].append(ruta)
    # Anuncios solo donde hay contenido
    if pg.anuncios and pg.palabras < PALABRAS_MIN_CON_ANUNCIO:
        problemas["anuncio"].append("%s (%d palabras)" % (ruta, pg.palabras))
    if pg.anuncios and ruta in ("404.html", "articulos/articulos.html") or (pg.anuncios and ruta.startswith("informacion/")):
        problemas["anuncio"].append("%s (los anuncios no van en páginas de error, de navegación ni legales)" % ruta)

duplicados_t = {t: r for t, r in titulos.items() if len(r) > 1}
duplicados_d = {d: r for d, r in descripciones.items() if len(r) > 1}

reglas = [
    ("titulo", "Páginas sin <title>"),
    ("h1", "Páginas que no tienen exactamente un <h1>"),
    ("lang", "Páginas sin lang=\"es\" o sin viewport"),
    ("canon", "Páginas cuyo canonical no es su dirección pública"),
    ("legal", "Páginas sin enlace a las páginas legales o de contacto"),
    ("enlaces", "Enlaces internos rotos"),
    ("rel", "Enlaces con target=\"_blank\" sin rel=\"noopener\""),
    ("anuncio", "Huecos de anuncio donde no deben ir"),
    ("robots", "404 sin noindex"),
]
for k, texto in reglas:
    if problemas[k]:
        pendiente.append("%s: %s" % (texto, "; ".join(problemas[k][:8])))
if duplicados_t:
    pendiente.append("Títulos repetidos (Google los trata como contenido duplicado): %s" % "; ".join("%r en %s" % (t, ", ".join(r)) for t, r in duplicados_t.items()))
if duplicados_d:
    pendiente.append("Descripciones repetidas: %s" % "; ".join("%r en %s" % (d[:50], ", ".join(r)) for d, r in duplicados_d.items()))
if problemas["desc"]:
    avisos.append("Descripciones fuera de 70–170 caracteres (Google las recorta o las reescribe): %s" % "; ".join(problemas["desc"]))
if not any(problemas[k] for k in ("titulo", "h1", "lang", "canon", "legal", "enlaces", "rel", "anuncio", "robots")) and not duplicados_t and not duplicados_d:
    listo.append("%d páginas revisadas: título y descripción únicos, un h1, canonical correcto, enlaces internos y anclas válidos, "
                 "pie con las páginas legales en todas." % len(paginas))

# Contenido propio: guías y textos
guias = {p: pg for p, pg in paginas.items() if p.startswith("articulos/") and p != "articulos/articulos.html"}
if len(guias) < MIN_GUIAS:
    pendiente.append("Hay %d guías y AdSense valora un sitio con contenido propio abundante: escribe al menos %d (gen/articulos/)." % (len(guias), MIN_GUIAS))
cortas = ["%s (%d)" % (p, g.palabras) for p, g in sorted(guias.items()) if g.palabras < PALABRAS_MIN_GUIA]
if cortas:
    pendiente.append("Guías con menos de %d palabras: %s. Amplíalas: el contenido escaso es el motivo de rechazo más habitual." % (PALABRAS_MIN_GUIA, ", ".join(cortas)))
if len(guias) >= MIN_GUIAS and not cortas:
    listo.append("%d guías propias, de %d a %d palabras, cada una con sus fuentes y su fecha de revisión."
                 % (len(guias), min(g.palabras for g in guias.values()), max(g.palabras for g in guias.values())))
sin_fuentes = [p for p in guias if 'class="art-fuentes"' not in leer(p)]
if sin_fuentes:
    pendiente.append("Guías sin apartado de fuentes: %s" % ", ".join(sin_fuentes))

# Las páginas legales dicen lo que la ley pide
aviso = leer("informacion/aviso-legal.html") if "informacion/aviso-legal.html" in paginas else ""
privacidad = leer("informacion/politica-de-privacidad.html") if "informacion/politica-de-privacidad.html" in paginas else ""
cookies = leer("informacion/politica-de-cookies.html") if "informacion/politica-de-cookies.html" in paginas else ""
for nombre, texto, necesarios in (
        ("Aviso legal", aviso, ("Titular", "NIF o CIF", "Domicilio", "Correo electrónico", "Ley 34/2002")),
        ("Política de privacidad", privacidad, ("Responsable", "Base", "Conservación", "Tus derechos", "aepd.es", "Google")),
        ("Política de cookies", cookies, ("Elementos propios", "Google AdSense", "Cómo cambiar tu elección"))):
    falta = [x for x in necesarios if x not in texto]
    if falta:
        pendiente.append("%s: faltan apartados esperados: %s" % (nombre, ", ".join(falta)))
    else:
        listo.append("%s: contiene los apartados que exige la normativa." % nombre)

print("PENDIENTE (%d)" % len(pendiente))
for t in pendiente:
    print("  - " + t)
if avisos:
    print("\nAVISOS (%d)" % len(avisos))
    for t in avisos:
        print("  - " + t)
print("\nLISTO (%d)" % len(listo))
for t in listo:
    print("  - " + t)
sys.exit(1 if pendiente else 0)
