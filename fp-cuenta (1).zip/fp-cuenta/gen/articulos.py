# -*- coding: utf-8 -*-
"""
Carga las guías (artículos) de gen/articulos/*.html.

Cada archivo empieza con un bloque de metadatos en un comentario HTML y sigue con el cuerpo del artículo:

    <!--
    titulo: Qué pasa si pierdes la evaluación continua en FP
    seo: Título corto para la pestaña y Google (máx. ~50 caracteres; si lo omites se usa el título)
    descripcion: Texto de 150-160 caracteres para Google y para la entradilla.
    resumen: Frase corta para el índice de guías.
    revisado: 2026-11-12
    orden: 1
    relacionados: otro-slug, otro-slug-mas
    herramientas: faltas, normativa
    fuentes:
    - Título de la fuente | https://enlace
    - Otro título | https://enlace
    -->
    <div class="art-resumen">…</div>
    <h2>…</h2>
    <p>…</p>

El nombre del archivo (sin .html) es la dirección de la guía. Los enlaces entre páginas se escriben con el nombre corto
(href="calculadora-faltas.html", href="otra-guia.html") y construir.py los convierte en rutas reales.
"""
import glob
import os
import re

CLAVES_UNA_LINEA = ("titulo", "seo", "descripcion", "resumen", "revisado", "orden", "relacionados", "herramientas")


def _lista(valor):
    return [x.strip() for x in valor.split(",") if x.strip()]


def leer(ruta):
    with open(ruta, encoding="utf-8") as f:
        texto = f.read()
    m = re.match(r"\s*<!--\s*\n(.*?)\n-->\s*\n?", texto, re.S)
    if not m:
        raise SystemExit("%s: falta el bloque de metadatos al principio (mira gen/articulos.py)." % ruta)
    meta, fuentes, en_fuentes = {}, [], False
    for linea in m.group(1).splitlines():
        if en_fuentes and linea.strip().startswith("-"):
            t, _, u = linea.strip()[1:].partition("|")
            if not t.strip() or not u.strip().startswith("http"):
                raise SystemExit("%s: fuente mal escrita (usa «- Título | https://…»): %r" % (ruta, linea))
            fuentes.append((t.strip(), u.strip()))
            continue
        clave, _, valor = linea.partition(":")
        clave = clave.strip()
        if clave == "fuentes":
            en_fuentes = True
        elif clave in CLAVES_UNA_LINEA:
            en_fuentes = False
            meta[clave] = valor.strip()
        elif linea.strip():
            raise SystemExit("%s: metadato desconocido %r" % (ruta, linea))
    for k in ("titulo", "descripcion", "resumen", "revisado"):
        if not meta.get(k):
            raise SystemExit("%s: falta «%s» en los metadatos." % (ruta, k))
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", meta["revisado"]):
        raise SystemExit("%s: «revisado» debe ser AAAA-MM-DD." % ruta)
    if not fuentes:
        raise SystemExit("%s: una guía debe citar al menos una fuente." % ruta)
    cuerpo = texto[m.end():].strip()
    return {
        "slug": os.path.splitext(os.path.basename(ruta))[0],
        "titulo": meta["titulo"],
        "seo": meta.get("seo", meta["titulo"]),
        "descripcion": meta["descripcion"],
        "resumen": meta["resumen"],
        "revisado": meta["revisado"],
        "orden": int(meta.get("orden", "99")),
        "relacionados": _lista(meta.get("relacionados", "")),
        "herramientas": _lista(meta.get("herramientas", "")),
        "fuentes": fuentes,
        "cuerpo": cuerpo,
        "palabras": len(re.findall(r"\w+", re.sub(r"<[^>]+>", " ", cuerpo))),
    }


def cargar(carpeta):
    arts = [leer(p) for p in sorted(glob.glob(os.path.join(carpeta, "*.html")))]
    arts.sort(key=lambda a: (a["orden"], a["slug"]))
    slugs = {a["slug"] for a in arts}
    for a in arts:
        for r in a["relacionados"]:
            if r not in slugs:
                raise SystemExit("%s: relacionados apunta a una guía que no existe: %s" % (a["slug"], r))
    return arts
