#!/usr/bin/env python3
"""Crea fp-cuenta-web.zip: solo los archivos que se suben al alojamiento.

Uso:  python3 gen/empaquetar.py

Deja fuera lo que no debe publicarse: los generadores de gen/, los .md (LEEME, IDEAS, PUBLICAR),
los .json de cada comunidad (la web usa su datos.js) y las copias de seguridad. Dentro del zip,
index.html queda en la raíz, que es lo que piden Cloudflare Pages, Netlify y GitHub Pages.
Antes de empaquetar ejecuta  python3 gen/construir.py  para que todo esté al día.
"""
import os
import sys
import zipfile

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SALIDA = os.path.join(RAIZ, 'fp-cuenta-web.zip')

CARPETAS_FUERA = {'gen', 'publicar', '__pycache__', '.git', 'node_modules'}
EXTENSIONES_FUERA = {'.md', '.py', '.pyc', '.zip', '.bak', '.tmp'}
NOMBRES_FUERA = {'.DS_Store', 'Thumbs.db'}
# comunidad.json y ciclos.json son los datos de partida: la web lee el datos.js que se genera a partir de ellos
JSON_FUERA = {'comunidad.json', 'ciclos.json', 'sitio.json'}
OBLIGATORIOS = ['index.html', '404.html', 'robots.txt', 'sitemap.xml', 'ads.txt']


def incluir(ruta_rel):
    partes = ruta_rel.split('/')
    if any(p in CARPETAS_FUERA for p in partes[:-1]):
        return False
    nombre = partes[-1]
    if nombre in NOMBRES_FUERA or nombre in JSON_FUERA:
        return False
    return os.path.splitext(nombre)[1].lower() not in EXTENSIONES_FUERA


def main():
    archivos = []
    for carpeta, subcarpetas, nombres in os.walk(RAIZ):
        subcarpetas[:] = sorted(d for d in subcarpetas if d not in CARPETAS_FUERA)
        for n in sorted(nombres):
            rel = os.path.relpath(os.path.join(carpeta, n), RAIZ).replace(os.sep, '/')
            if incluir(rel):
                archivos.append(rel)

    faltan = [o for o in OBLIGATORIOS if o not in archivos]
    if faltan:
        sys.exit('Faltan archivos: ' + ', '.join(faltan) + '. Ejecuta antes  python3 gen/construir.py')

    if os.path.exists(SALIDA):
        os.remove(SALIDA)
    with zipfile.ZipFile(SALIDA, 'w', zipfile.ZIP_DEFLATED) as z:
        for rel in archivos:
            z.write(os.path.join(RAIZ, rel), rel)

    kb = os.path.getsize(SALIDA) / 1024
    print(f'Creado {os.path.basename(SALIDA)}: {len(archivos)} archivos, {kb:.0f} KB')
    print('Súbelo tal cual a Cloudflare Pages (Subir recursos) o descomprímelo y sube la carpeta.')


if __name__ == '__main__':
    main()
