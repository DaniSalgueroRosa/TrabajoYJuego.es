# Publicar FP Cuenta, que se encuentre en Google y ganar dinero con ella

Guía escrita el 12 de noviembre de 2026. Los precios y los paneles de las empresas cambian: lo que pone aquí es lo que encontré al
prepararla, así que **comprueba cada precio y cada pantalla antes de pagar o pulsar**. No soy asesor fiscal ni abogado: donde hay
impuestos o leyes, es una orientación para que sepas qué preguntar, no un consejo profesional.

## 0. El plan en una página

| Cuándo | Qué | Tiempo |
|---|---|---|
| Mañana | Comprar el dominio, rellenar tus datos, subir la web, comprobarla y registrarla en Google Search Console | 2–3 h |
| Semana 1 | Dejar que Google la indexe. Escribir las primeras guías nuevas | poco cada día |
| Semanas 2–3 | Con unas 10–15 guías y la web ya indexada, **solicitar AdSense** | 30 min |
| Días o semanas después | Esperar la revisión. Si te aprueban, seguir la sección 6 | |
| Meses | Posicionar (sección 7). El dinero llega despacio: mira la sección 8 antes de hacerte ilusiones | |

**Mi recomendación sobre AdSense.** Puedes solicitarlo mañana mismo, pero con una web de un día y siete guías el riesgo de que te digan
«contenido de poco valor» es mayor. Google no da un número mínimo de páginas; pide contenido original que aporte algo y una buena
experiencia de uso. Es más seguro publicar, dejar que Google la indexe, añadir guías y solicitarlo entonces. Es una opinión mía, no una
regla de Google.

## 1. Antes de subir nada: tus datos y el zip

La web se genera con unos scripts de Python (solo usan lo que viene con Python, no hay que instalar nada). Tienes Python si al escribir
`python3 --version` (en Windows, `py --version`) sale un número.

**Si no tienes Python**, no pasa nada: cuando tengas el dominio, dime en el chat los datos de abajo y te devuelvo el zip listo para subir.

1. **`gen/sitio.json`** (ábrelo con el Bloc de notas):
   - `dominio`: tu dominio con `https://` y sin barra final, **tal como quieres que se vea**: `https://tudominio.es` o
     `https://www.tudominio.es`. Elige una de las dos y haz que la otra redirija a ella (sección 3, paso 5).
   - `titular`: `nombre`, `nif`, `domicilio` (y `telefono` si quieres). Son los datos de la persona que está detrás de la web.
   - `hosting`: `Cloudflare, Inc.` (si usas Cloudflare).
   - `formulario`: déjalo vacío; el buzón de sugerencias abre el correo de quien visita.
2. **`compartido/configuracion.js`**: cambia `contactEmail` por el correo donde quieras recibir mensajes. Deja `adsenseClient` vacío por ahora.
3. En una terminal, dentro de la carpeta `fp-cuenta`:
   ```
   python3 gen/construir.py
   python3 gen/antes_de_publicar.py
   python3 gen/empaquetar.py
   ```
   - `construir.py` escribe todas las páginas con tus datos (dominio, canonical, sitemap, textos legales).
   - `antes_de_publicar.py` te dice qué falta. **No debe quedar nada «PENDIENTE» salvo el ID de AdSense.** Si quedan marcadores amarillos
     en las páginas legales, es que falta un dato.
   - `empaquetar.py` crea **`fp-cuenta-web.zip`**: solo lo que se sube (sin `gen/`, sin los `.md`, sin los `.json`). Ese es el zip que subes.

**Dos cosas sobre tus datos.**
- Con anuncios la web tiene actividad económica. La Ley de Servicios de la Sociedad de la Información (LSSI-CE, art. 10) pide
  identificar a quien presta el servicio (nombre, domicilio, NIF y un medio de contacto). Por eso el aviso legal los enseña, y
  **serán públicos**. Si el domicilio te incomoda, pregunta a un gestor qué opciones tienes antes de publicar.
- Si no quieres que tu correo personal salga en la web, crea uno solo para esto o, cuando el dominio esté en Cloudflare, usa el
  reenvío de correo gratuito de Cloudflare (*Email Routing*): `contacto@tudominio.es` te llega a tu bandeja de siempre.

## 2. Comprar un dominio muy barato para un año

Lo que importa: **el precio del primer año engaña; mira lo que cuesta renovar.** Esto encontré en noviembre de 2026:

| Dónde | Dominio | Primer año | Renovación | Ojo con |
|---|---|---|---|---|
| Hostinger | .es | 0,01 € | 9,99 € | La renovación automática viene activada: desactívala si solo lo quieres un año. La oferta puede variar al comprar. |
| OVHcloud | .es | 5,99 € + IVA | 6,99 € + IVA | Es la opción barata «de verdad» a largo plazo. |
| Cloudflare Registrar | .com | unos 10–11 $ (precio de coste) | lo mismo | Sin recargo ni subida al renovar. No des por hecho que venda `.es`: búscalo en su buscador y, si no sale, olvídalo. |
| Arsys | .es | unos 10 € | 25 € | La renovación es mucho más cara. |

**Qué haría yo.**
- Si solo quieres probar un año al mínimo coste: **un `.es` en Hostinger por 0,01 €**, con la renovación automática desactivada y un aviso en
  el calendario un mes antes de que caduque.
- Si la web te importa más de un año: **OVHcloud (.es, unos 7 € + IVA al año) o un `.com` en Cloudflare (unos 10 $/año)**. Un dominio
  nuevo no sube en Google hasta pasados meses; si lo dejas caducar, pierdes todo lo que hayas ganado. Lo que cuesta mantenerlo es poco al
  lado de eso.
- **Un `.es` encaja bien** con una web de FP en España. Evita extensiones raras (`.xyz`, `.top`, `.click`…): no están prohibidas, pero dan
  menos confianza y AdSense y los lectores las miran peor.
- Al comprar: busca el nombre (por ejemplo `fpcuenta.es`), **no marques extras** (hosting, correo, «protección», SSL de pago: no los
  necesitas) y activa la privacidad de datos del dominio si te la ofrecen (WHOIS), para que tu dirección no quede pública en el registro.
- Para registrar un `.es` te pedirán tus datos reales (nombre, NIF, dirección). Es normal.

## 3. Publicar la web gratis en Cloudflare Pages

Cloudflare Pages aloja páginas estáticas como esta gratis, con HTTPS automático. Cloudflare está empujando los proyectos nuevos hacia
«Workers» (que también sirve archivos estáticos), pero Pages sigue funcionando, y para subir un zip es lo más sencillo. Si el panel te
manda a Workers, el proceso equivale: crear un proyecto, subir los archivos y asignar el dominio. Los nombres de los botones pueden cambiar.

1. Crea una cuenta gratis en <https://dash.cloudflare.com/sign-up>.
2. **Añade tu dominio** (*Add a domain* / *Onboard a domain*), elige el plan **Free**, y Cloudflare te dará **dos servidores de nombres**
   (nameservers, tipo `xxx.ns.cloudflare.com`). En el sitio donde compraste el dominio, cambia sus nameservers por esos dos. Tarda de
   minutos a unas horas. (Si compraste el dominio en Cloudflare, ya está hecho.) Tener el DNS en Cloudflare es lo que permite usar el
   dominio sin `www` y verificar Google con un clic.
3. En Cloudflare: **Workers & Pages → Create → Pages → Upload assets** (subir recursos). Ponle un nombre al proyecto y sube **`fp-cuenta-web.zip`**
   (o arrastra la carpeta descomprimida). Pulsa *Deploy*. Te dará una dirección tipo `nombre.pages.dev`: ábrela y mira que se ve bien.
4. En el proyecto: **Custom domains → Set up a custom domain** y escribe tu dominio. Cloudflare crea el DNS y el certificado solo.
   Espera a que ponga *Active* (pueden ser unos minutos).
5. Añade también la otra versión (con o sin `www`) y haz que redirija a la que elegiste en `sitio.json`. En Cloudflare:
   *Rules → Redirect Rules*, o simplemente añade las dos como dominio personalizado y deja la principal en `sitio.json`.
6. **Comprueba** (con el navegador, desde el móvil también):
   - `https://tudominio.es/` carga con candado.
   - Las calculadoras funcionan, el modo oscuro cambia, el menú abre.
   - `https://tudominio.es/robots.txt`, `/sitemap.xml` y `/ads.txt` se ven.
   - Una dirección que no existe (`/hola`) muestra la página 404 de la web.
   - Pulsa Ctrl+U en la portada y busca `canonical`: debe apuntar a **tu dominio**, no a `pages.dev`.
7. **Cada vez que cambies algo**: `python3 gen/construir.py` → `python3 gen/empaquetar.py` → en Cloudflare, tu proyecto →
   *Create new deployment* y subes el zip nuevo. La web antigua se sustituye.

**Sobre `nombre.pages.dev`.** La web también será accesible ahí, pero cada página lleva su dirección canónica con tu dominio, así que Google
entenderá que la buena es la tuya. No difundas la de `pages.dev`.

**Alternativas si Cloudflare te da problemas:** Netlify (arrastrar la carpeta en *Netlify Drop*) o GitHub Pages. Para ambas sirve el mismo zip;
con tu dominio tendrás que seguir sus instrucciones de DNS.

## 4. Que Google la encuentre

Google encuentra webs siguiendo enlaces, pero tú puedes avisarle directamente, sin coste, con **Google Search Console**.

1. Entra en <https://search.google.com/search-console> con tu cuenta de Google.
2. Añade una propiedad de tipo **Dominio** y escribe tu dominio. Google te da un registro **TXT**. Pégalo en el DNS de tu dominio
   (en Cloudflare: *DNS → Records → Add record*, tipo `TXT`, nombre `@`, y el valor que te dé Google). Vuelve a Search Console y pulsa
   *Verificar* (puede tardar unos minutos).
3. **Sitemaps** → escribe `sitemap.xml` → *Enviar*. En 1–3 días verás cuántas páginas ha leído.
4. **Inspección de URL** → pega la portada (`https://tudominio.es/`) → *Solicitar indexación*. Repite con las calculadoras y las guías
   más importantes. Hay un límite diario de solicitudes: no hace falta ir al máximo.
5. Mira el informe **Páginas** (indexación) después de unos días: te dice qué está indexado y por qué no lo está lo demás.
6. Opcional: **Bing Webmaster Tools** (<https://www.bing.com/webmasters>). Permite importar lo de Search Console y sirve a los
   buscadores que usan Bing.

**Cuánto tarda.** Que Google conozca la web: días. Que la muestre en los primeros resultados para búsquedas competidas: meses, y
no está garantizado. No hay atajos legítimos; el trabajo es la sección 7.

No hay Google Analytics en la web. No lo añadas todavía: pide consentimiento y cambiar las páginas legales. Search Console te da lo importante
(búsquedas, clics, posición) sin tocar la web.

## 5. Solicitar AdSense

**Requisitos que tienes que cumplir tú.**
- Ser **mayor de 18 años**, con tus datos reales (nombre y dirección de pago).
- Una web **propia**, con dominio propio y HTTPS: ya la tendrás.
- **Contenido original** que aporte algo. Google no admite webs que copian de otros. Las siete guías están escritas desde cero a partir
  de fuentes oficiales; **léelas con calma y corrígelas** con lo que sepas de la realidad de tu centro (las he redactado yo, una IA: Google
  no penaliza por eso, pero sí el contenido masivo y sin valor, lo haga quien lo haga).
- Páginas de **Sobre nosotros, Contacto, Aviso legal, Privacidad y Cookies**, visibles en todas las páginas: ya están.
- **Navegación clara**, sin enlaces rotos, que se vea bien en el móvil: ya está comprobado.

**Pasos.**
1. Regístrate en <https://adsense.google.com> con tu cuenta de Google. Te pide la dirección de la web, tu país y aceptar las condiciones.
2. AdSense te dará tu **ID de editor** (`ca-pub-…`). Abre `compartido/configuracion.js`, pégalo en `adsenseClient`, y ejecuta
   `python3 gen/construir.py` y `python3 gen/empaquetar.py`. Sube el zip nuevo a Cloudflare. Ahora todas las páginas llevan la metaetiqueta de
   AdSense y `ads.txt` queda con tu ID.
3. En AdSense → **Sitios** → tu web → elige verificar con **metaetiqueta** (ya está en el `<head>`; no hace falta pegar nada) o con `ads.txt`.
4. Pulsa **Solicitar revisión**.
5. **Espera.** No hay plazo fijo: desde unos días a unas semanas. Mientras tanto, sigue publicando guías. No hace falta tener anuncios puestos.

**Si te rechazan.** Es frecuente. Te dirá el motivo (contenido de poco valor, falta de páginas esenciales, experiencia de uso…). Corrige lo
que dice, añade más guías con valor real y vuelve a solicitar la revisión. No contrates a nadie que te prometa «aprobación garantizada».

## 6. Cuando te aprueben

1. **Crea los bloques de anuncios.** En AdSense → *Anuncios → Por bloque de anuncios → Anuncio display*, formato **adaptable**. Crea cinco
   (portada, faltas, notas, normativa, guías). Copia el número de `data-ad-slot` de cada uno en `adsenseSlots` de `configuracion.js`.
   Ejecuta `construir.py` y `empaquetar.py` y sube el zip. (Alternativa: activar *Anuncios automáticos* y dejar los huecos vacíos.)
2. **Mensaje de consentimiento de Google (hazlo antes de mostrar anuncios en España).** En AdSense → *Privacidad y mensajes* crea y publica el
   mensaje de **normativa europea** para tu sitio. Después pon `consentimiento: 'google'` en `configuracion.js` y vuelve a construir y subir:
   los textos legales de la web cambian solos. Para mostrar anuncios personalizados en la UE y el Reino Unido, Google exige una plataforma
   de consentimiento certificada; la suya lo es y es gratis. El aviso propio de la web no lo es.
3. **Datos de pago.** AdSense → *Pagos → Información de pagos*: tu nombre y dirección (deben ser los reales) y tu cuenta bancaria
   (transferencia SEPA). Google puede pedirte además datos fiscales.
4. **El PIN.** Cuando ganes unos 10 €, Google te enviará una carta por correo postal con un PIN de 6 dígitos para verificar tu dirección. Tarda
   semanas. Escríbelo con cuidado: tienes pocos intentos.
5. **Cuándo cobras.** El umbral de pago en euros es **70 €**. Si tu saldo lo supera y no hay retenciones, te pagan **entre el 21 y el 26 del mes
   siguiente**, y la transferencia tarda otros 4–10 días en llegar al banco.
6. Mira que `https://tudominio.es/ads.txt` tiene tu ID.

**Reglas que no debes romper (te pueden cerrar la cuenta):**
- **Nunca hagas clic en tus propios anuncios**, ni pidas a otros que lo hagan, ni ofrezcas nada a cambio de clics. Ni «para probar».
- No compres tráfico dudoso ni uses «servicios de visitas».
- Los anuncios van siempre etiquetados («Publicidad») y lejos de botones y campos para que nadie pulse sin querer. Así está hecho; no lo cambies.
- No pongas anuncios en páginas sin contenido propio (por eso no hay en la 404, el contacto ni las páginas legales).
- No copies textos de otras webs.

## 7. Posicionarla: qué sí funciona

La parte técnica ya está hecha: páginas rápidas y ligeras, adaptadas al móvil, un título y una descripción únicos en cada página, direcciones
canónicas, sitemap, datos estructurados y enlaces internos entre calculadoras y guías. Lo que queda es lo que Google valora de verdad:
**que a la gente le sirva y que vuelva**.

1. **Contenido útil, con regularidad.** Una guía por semana, bien hecha, mejor que diez de golpe. Piensa en lo que busca un alumno de FP:
   - Cuántas faltas puedes tener **en tu comunidad** (una guía por comunidad: Andalucía, Madrid, Cataluña…, con la normativa de cada una).
   - La FCT: qué es, cuántas horas, cómo se evalúa.
   - Convocatorias: cuántas hay y qué pasa si suspendes un módulo.
   - Cómo se calcula la nota media del ciclo.
   - Convalidaciones y exenciones de módulos.
   - FP dual: cómo funciona.
   Cada una con **fuentes oficiales y fecha de revisión**, como las siete que ya hay. Dime el tema y la escribimos juntos.
2. **Responder la pregunta de verdad.** Pon la respuesta arriba, en las primeras líneas, y luego explícala. Los títulos deben parecerse a lo que
   la gente teclea («cuántas faltas puedes tener en FP»), no a eslóganes.
3. **Mantenerla al día.** La normativa cambia. Cuando compruebes una guía, actualiza la fecha `revisado` del encabezado del archivo en `gen/articulos/`
   (solo si de verdad la has revisado) y vuelve a construir y subir.
4. **Enlaces de otras webs** (lo que más pesa y lo más difícil), solo de forma honesta: compártela donde ayude de verdad (grupos de alumnos,
   foros y comunidades de FP, redes sociales, institutos o profesores que quieran enlazarla). No compres enlaces ni los intercambies en masa:
   Google lo considera spam y puede hundir la web.
5. **Mirar los datos en Search Console.** Qué búsquedas te traen visitas, cuáles te muestran sin clics (mejora el título y la descripción) y
   cuáles aparecen en la posición 8–20 (mejora esa guía). Es lo más rentable que puedes hacer cada semana.
6. **Calidad de uso.** Que sea rápida, que funcione en móvil y que las calculadoras no fallen. Ya está cuidado: no lo estropees añadiendo
   scripts de terceros sin necesidad.

Cuando alguien busque «calculadora faltas FP» o «cuántas faltas puedes tener en FP», conviene que **la herramienta y la guía se refuercen**:
la guía lleva a la calculadora, y la calculadora a la normativa. Ya están enlazadas; mantén eso al añadir páginas nuevas.

## 8. El dinero: cuánto es realista

Lo que cobras depende de las **páginas vistas** y del **RPM** (lo que paga AdSense por cada 1000 páginas vistas). El RPM cambia mucho según
el tema, el país y la época: no tengo un dato fiable para esta web, así que lo que sigue es un ejemplo, **no una previsión**:

| RPM supuesto | Páginas vistas para llegar al umbral de 70 € |
|---|---|
| 1 € | 70.000 |
| 3 € | unas 23.300 |
| 5 € | 14.000 |

Tu cuenta de AdSense te enseñará el RPM real a las pocas semanas. Es probable que haya más visitas cuando empieza el curso y en las
evaluaciones (septiembre–octubre, enero, junio), y menos en verano. Lo normal en una web nueva es pasar **varios meses** con muy pocos
ingresos mientras Google la va conociendo. Si algún día llega a ser algo más, será porque tiene muchas guías buenas y mucha gente que la usa.

## 9. Impuestos (consulta a un gestor)

Esto es solo para saber qué preguntar. Según las guías fiscales que revisé:
- Los ingresos de AdSense **cuentan como actividad económica** y se declaran en el IRPF. Google **no retiene IRPF español**: lo declaras
  y lo pagas tú.
- Quien te paga es Google Ireland (otro país de la UE). Por eso suele tratarse como una operación intracomunitaria **sin IVA en la factura**
  (inversión del sujeto pasivo), lo que implica estar dado de alta en el censo de operadores intracomunitarios (ROI) y, normalmente,
  presentar el modelo 349.
- Los autónomos presentan además el pago fraccionado trimestral del IRPF (modelo 130) y pagan cuota de autónomos. La cuota y las ayudas para
  nuevos autónomos cambian cada año: pregúntalo en la Seguridad Social o a un gestor.
- Aunque ganes poco, no conviene ignorarlo. **Tienes meses por delante hasta el primer cobro (70 €)**: antes de que llegue, pregunta en la
  Agencia Tributaria o a una gestoría cómo te encaja (alta de autónomo, si compensa, qué epígrafe usar). Cuando tengas el alta, pon tus datos
  fiscales reales en `gen/sitio.json`.

## 10. Calendario de mantenimiento

- [ ] **Hoy:** poner en el calendario la fecha de caducidad del dominio (menos 30 días) y decidir si lo renuevas o desactivas la renovación.
- [ ] **Cada mes:** mirar Search Console (errores, búsquedas) y AdSense (avisos en *Política*).
- [ ] **Cada trimestre y cada septiembre:** revisar la normativa de las tres comunidades (porcentaje de faltas, horas, convocatorias) y actualizar
      `comunidades/*/comunidad.json`, las guías y las fechas de revisión.
- [ ] **Cada año:** revisar los textos legales (aviso legal, privacidad, cookies) por si algo cambia. El año del pie se actualiza solo.

## 11. Lista para mañana

- [ ] Elegir y comprar el dominio (sección 2).
- [ ] Rellenar `gen/sitio.json` y `contactEmail` (sección 1).
- [ ] `construir.py`, `antes_de_publicar.py`, `empaquetar.py` (sección 1).
- [ ] Cuenta de Cloudflare, dominio añadido y nameservers cambiados (sección 3).
- [ ] Subir `fp-cuenta-web.zip` y asignar el dominio (sección 3).
- [ ] Comprobar la web (sección 3, paso 6).
- [ ] Search Console: verificar, enviar `sitemap.xml`, solicitar indexación (sección 4).
- [ ] Leer las siete guías y corregir lo que no sea exacto en tu realidad.
- [ ] Apuntar el tema de la próxima guía.

## Fuentes

- AdSense, pagos y umbrales: <https://support.google.com/adsense/answer/7164701?hl=es> y <https://support.google.com/adsense/answer/1709871?hl=pt>
- AdSense, verificación de dirección (PIN): <https://support.google.com/adsense/answer/157667?hl=es-GB>
- AdSense, contenido original y experiencia de uso: <https://support.google.com/adsense/answer/10015918?hl=es>
- AdSense, política de privacidad y anunciantes de terceros: <https://support.google.com/adsense/answer/1348695?hl=es>
- Precios de dominios .es: <https://hackceleration.com/es/labs/mejor/registrador-de-dominios>, <https://www.arsys.es/dominios/precios>,
  <https://www.hostinger.com/es/dominios-baratos>
- Cloudflare Registrar (precio de coste): <https://www.cloudflare.com/products/registrar/>
- Cloudflare Pages y Workers: <https://developers.cloudflare.com/pages/migrations/migrating-from-workers/>
- Search Console (dominio, TXT, sitemap, indexación): <https://developers.google.com/search/blog/2019/09/auto-dns-verification?hl=es-419>
- Impuestos de AdSense en España: <https://www.billeo.es/blog/autonomo-influencer-streamer-youtuber-fiscalidad-2026>,
  <https://www.legalitas.com/actualidad/como-tributan-los-influencers>, <https://teamsystem.es/magazine/fiscalidad-google-adsense/>
